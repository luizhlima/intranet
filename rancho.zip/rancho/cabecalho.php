<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title><?php echo($_SESSION['sistema2']) ?></title>
<link rel="apple-touch-icon" sizes="120x120" href="favicon/logocma.png">
<link rel="icon" type="image/png" sizes="192x192" href="favicon/logocma.png">
<link rel="icon" type="image/png" sizes="32x32" href="favicon/logocma.png">
<link rel="icon" type="image/png" sizes="16x16" href="favicon/logocma.png">