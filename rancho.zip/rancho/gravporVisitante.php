<?php

require "versession.php";
include "conexao.php";

$datarancho = filter_input(INPUT_POST, "datarancho");

$registro = filter_input(INPUT_POST, "registro");

$posgrad = filter_input(INPUT_POST, "postograd");

$quemgrava = $_SESSION['user_pgradsimples2'] . " " . $_SESSION['user_guerra2'];

// VERIFICA A DISPONIBILIDADE DE DATAS
$convdata = strtotime(date_converter($datarancho));

$ds = date('D'); // pega o dia da semana da data atual

$dtlimite = date('Y-m-d', strtotime("+1 days"));
$dtcinco = date('Y-m-d', strtotime("+5 days"));
$dtquatro = date('Y-m-d', strtotime("+4 days"));
$dttres = date('Y-m-d', strtotime("+3 days"));
$erro = 0;


if ($registro <= 0) {


if ($convdata < strtotime($dtlimite)) {
    $msgerro = base64_encode('DATA DEVE SER MAIOR QUE A ATUAL!');
    $erro = 1;
}

if ($ds == 'Fri') { //verifica se o dia da semana é sexta-feira
    if ($convdata < strtotime($dtquatro)) {
        $msgerro = base64_encode("ARRANCHAMENTO LIBERADO SOMENTE A PARTIR DE " . date('d/m/Y', strtotime($dttres)));
        $erro = 1;
    }
}

if ($ds == 'Sat') { //verifica se o dia da semana é sábado
    if ($convdata < strtotime($dttres)) {
        $msgerro = base64_encode("ARRANCHAMENTO LIBERADO SOMENTE A PARTIR DE " . date('d/m/Y', strtotime($dttres)));
        $erro = 1;
    }
}

if ($erro < 1) {

    try {
        $pdo2 = conectar2("arranchamento");

        $motivo = filter_input(INPUT_POST, "motivo");
        $qtdVisitante = filter_input(INPUT_POST, "qtdVisitante");
        $cafe = filter_input(INPUT_POST, "cafe");
        $almoco = filter_input(INPUT_POST, "almoco");
        $jantar = filter_input(INPUT_POST, "jantar");

        if ($cafe=='') $cafe = 0;
        if ($almoco=='') $almoco = 0;
        if ($jantar=='') $jantar = 0;

        //$sql = "INSERT INTO visitante (data, motivo, idposgrad, totalvisitantes, totalcafe, totalalmoco, totaljanta, quemgrava) VALUES ('$datarancho', '$motivo', $posgrad , $qtdVisitante, $cafe, $almoco, $jantar, '')";

        $stmtez = $pdo2->prepare("INSERT INTO visitante (data, motivo, idposgrad, totalvisitantes, totalcafe, totalalmoco, totaljanta, quemgrava) VALUES ('$datarancho', '$motivo', $posgrad , $qtdVisitante, $cafe, $almoco, $jantar, '$quemgrava')");
        $executa = $stmtez->execute();

        $horafim = date("H:i:s");
        $diftime = calculaTempo($horaini, $horafim);
        $msgerro = base64_encode(" registros gravados, atualizados em: " . $diftime . "(H:m:s)");
        //$msgerro = base64_encode("SQL:".$sql);

    } catch (PDOException $e) {
        $msgerro = base64_encode(" Erro ao inserir os dados: " . $msgerro);
    }

}

} else {

    try {
          $pdo2 = conectar2("arranchamento");
          $stmtez = $pdo2->prepare("DELETE FROM visitante WHERE id = $registro");
          $executa = $stmtez->execute();
    } catch (PDOException $e) {
        $msgerro = base64_encode(" Erro ao excluir os dados: " . $msgerro);
    }

    $msgerro = base64_encode(" registro excluido com sucesso ! ");
}


header('Location: visitantes.php?token=' . $msgerro);

?>
