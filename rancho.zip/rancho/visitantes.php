<?php
require "versession.php";
include "conexao.php";
$token = base64_decode(filter_input(INPUT_GET, "token"));
$p2 = conectar2("arranchamento");
$p1 = conectar("membros");
$sistema = base64_encode($_SESSION['sistema2']);
?>
<!doctype html>


<script type="text/javascript">

function remove(id) {
   document.getElementById("registro").value = id;
   document.getElementById("formulario").method = "POST";
   document.getElementById("formulario").action="gravporVisitante.php";
   document.getElementById("formulario").submit();
}

function ajustarmaximo() {
    document.getElementById("cafe").max = document.getElementById("qtdVisitante").value;
    document.getElementById("almoco").max = document.getElementById("qtdVisitante").value;
    document.getElementById("jantar").max = document.getElementById("qtdVisitante").value;
}

</script>


<html lang="pt-BR" class="fixed">
    <head>
        <?php include 'cabecalho.php'; ?>
        <script src="vendor/pace/pace.min.js"></script>
        <link href="vendor/pace/pace-theme-minimal.css" rel="stylesheet" />
        <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="vendor/animate.css/animate.css">
        <link rel="stylesheet" href="vendor/toastr/toastr.min.css">
        <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css">
        <link rel="stylesheet" href="stylesheets/css/style.css">
        <link rel="stylesheet" href="vendor/select2/css/select2.min.css">
        <link rel="stylesheet" href="vendor/select2/css/select2-bootstrap.min.css">
        <link rel="stylesheet" href="vendor/data-table/media/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="vendor/data-table/extensions/Responsive/css/responsive.bootstrap.min.css">
        <link href="vendor/pace/pace-theme-minimal.css" rel="stylesheet" />
        <link rel="stylesheet" href="vendor/bootstrap_date-picker/css/bootstrap-datepicker3.min.css">
        <link rel="stylesheet" href="vendor/bootstrap_time-picker/css/timepicker.css">
        <link rel="stylesheet" href="vendor/bootstrap_color-picker/css/bootstrap-colorpicker.min.css">
    </head>
    <body>
        <div class="wrap">
            <div class="page-header">
                <div class="leftside-header">
                    <?php include 'copright.php' ?>
                    <div id="menu-toggle" class="visible-xs toggle-left-sidebar" data-toggle-class="left-sidebar-open"
                         data-target="html">
                        <i class="fa fa-bars" aria-label="Toggle sidebar">
                        </i>
                    </div>
                </div>
                <?php include 'painel_usu.php'; ?>
            </div>
        </div>
        <div class="page-body">
            <div class="left-sidebar">
                <!-- left sidebar HEADER -->
                <div class="left-sidebar-header">
                    <div class="left-sidebar-title">
                        Menu de Navegação
                    </div>
                    <div class="left-sidebar-toggle c-hamburger c-hamburger--htla hidden-xs"
                         data-toggle-class="left-sidebar-collapsed" data-target="html">
                        <span>
                        </span>
                    </div>
                </div>
                <?php include 'menu_opc.php'; ?>
            </div>
        </div>
        <div class="content">
            <div class="content-header">
                <div class="leftside-content-header">
                    <ul class="breadcrumbs">
                        <li>
                            <i class="fa fa-cutlery" aria-hidden="true">
                            </i>
                            <a href="#"> Arranchamento de Visitantes por Quantitativo</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row animated fadeInUp">
                <div class="col-sm-12">
                    <form id="formulario" action="gravporVisitante.php" method="post">

                        <input type="hidden" value="0" id="registro" name="registro" />

                        <div class="row">
                            <div class="col-sm-4">
                                <div class="panel">
                                    <div class="panel-header  panel-warning">
                                        <h3 class="panel-title">Data</h3>
                                        <div class="panel-actions">
                                            <ul>
                                                <li class="action toggle-panel panel-expand"><span></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-content">
                                        <p>Escolha a data para realizar o arranchamento. </p>
                                        <div class="form-group">
                                            <label for="default-datepicker" class="col-sm-2 control-label ">Data</label>
                                            <div class="col-sm-10">
                                                <div class="input-group date" id="default-datepicker">
                                                    <span class="input-group-addon x-primary"><i class="fa fa-calendar"></i></span>
                                                    <input type="text" name="datarancho" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="panel">
                                    <div class="panel-header  panel-warning">
                                        <h3 class="panel-title">Motivo</h3>
                                        <div class="panel-actions">
                                            <ul>
                                                <li class="action toggle-panel panel-expand"><span></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-content">
                                        <p>Informo o Motivo do Arranchamento dos Visitantes</p>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                    <input type="text" name="motivo" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="panel">
                                    <div class="panel-header  panel-warning">
                                        <h3 class="panel-title">Posto/Graduação</h3>
                                        <div class="panel-actions">
                                            <ul>
                                                <li class="action toggle-panel panel-expand"><span></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-content">
                                        <p>Escolha o Posto/Graduação na lista abaixo.</p>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <select name="postograd" id="select2-example-basic" class="form-control" style="width: 100%" required>
                                                        <?php
                                                        $consulta = $p1->prepare("SELECT * FROM postograd ORDER BY id ASC");
                                                        $consulta->execute();
                                                        echo("<optgroup label='Posto / Graduação'>");
                                                        while ($reg = $consulta->fetch(PDO::FETCH_ASSOC)) :
                                                            /* Para recuperar um ARRAY utilize PDO::FETCH_ASSOC */
                                                            echo("<option value=" . $reg['id'] . ">" . $reg['postograd']."</option>");
                                                        endwhile;
                                                        echo("</optgroup>");
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="panel">
                                    <div class="panel-header  panel-warning">
                                        <h3 class="panel-title">Quantidade</h3>
                                        <div class="panel-actions">
                                            <ul>
                                                <li class="action toggle-panel panel-expand"><span></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-content">
                                        <p>Informe o total de visitantes por posto/graduação</p><br>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                 <input type="text" value="0" id="qtdVisitante" name="qtdVisitante" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-8">
                                <div class="panel">
                                    <div class="panel-header  panel-warning">
                                        <h3 class="panel-title">Refeição</h3>
                                        <div class="panel-actions">
                                            <ul>
                                                <li class="action toggle-panel panel-expand"><span></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="panel-content">
                                        <p>Informe a quantidade de militares que irão tomar:</p>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <div class="form-check form-check-inline">
                                                    <div class="col-sm-3"><label>Café</label> <input type="number" min="0" value="0" class="form-check-input form-control" name="cafe" id="cafe" onchange="ajustarmaximo();"></div>
                                                    <div class="col-sm-3"><label>Almoço</label> <input type="number" min="0" value="0" class="form-check-input form-control" name="almoco" id="almoco" onchange="ajustarmaximo();"></div>
                                                    <div class="col-sm-3"><label>Janta</label> <input type="number" min="0" value="0" class="form-check-input form-control" name="jantar" id="jantar" onchange="ajustarmaximo();"></div>
                                                    <br>
                                                    <div class="col-sm-3">
                                                       <button type="submit" class="btn btn-success form-control">
                                                          <i class="glyphicon glyphicon-hand-right">Confirma</i>
                                                       </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Tabela de visitantes arranchados -->
                        <div class="col-sm-12">
                            <div class="panel">
                                <div class="panel-content">
                                    <table id="responsive-table" class="data-table table table-striped table-hover responsive nowrap"
                                           cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>
                                                    Registro
                                                </th>
                                                <th>
                                                    Data
                                                </th>
                                                <th>
                                                    Motivo
                                                </th>
                                                <th>
                                                    Posto/Graduação
                                                </th>
                                                <th>
                                                    Total de Visitantes
                                                </th>
                                                <th>
                                                    Café
                                                </th>
                                                <th>
                                                    Almoço
                                                </th>
                                                <th>
                                                    Jantar
                                                </th>
                                                <th>
                                                    Quem Cadastrou?
                                                </th>
                                                <th>
                                                    Ação
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $listarVisitantes = $p2->prepare("SELECT * FROM visitante");
                                            $listarVisitantes->execute();
                                            while ($reg2 = $listarVisitantes->fetch(PDO::FETCH_ASSOC)) :
                                                /* Para recuperar um ARRAY utilize PDO::FETCH_ASSOC */
                                                echo("<tr>");
                                                echo("<td>" . $reg2['id'] . "</td>");
                                                echo("<td>" . $reg2['data'] . "</td>");
                                                echo("<td>" . $reg2['motivo'] . "</td>");
                                                $sql2 = "SELECT * FROM postograd WHERE id = :idpg";
                                                $stmt2 = $p1->prepare($sql2);
                                                $stmt2->bindParam(':idpg', $reg2['idposgrad'], PDO::PARAM_INT);
                                                $stmt2->execute();
                                                $descpg = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                                                $PGdesc = $descpg[0];
                                                echo("<td>" . $PGdesc["postograd"] . "</td>");
                                                echo("<td>" . $reg2['totalvisitantes'] . "</td>");
                                                echo("<td>" . $reg2['totalcafe'] . "</td>");
                                                echo("<td>" . $reg2['totalalmoco'] . "</td>");
                                                echo("<td>" . $reg2['totaljanta'] . "</td>");
                                                echo("<td>" . $reg2["quemgrava"] . "</td>");
                                                echo("<td> <a onclick='remove(".$reg2['id'].")'>Excluir<a/> </td>");
                                                echo("</tr>");
                                            endwhile;
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                            <!-- Tabela de visitantes arranchados -->

                        </div>
                    </form>
                </div>
            </div>

            <?php
            if ($token != "") {
                ?>
                <div class="alert alert-success fade in">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <h4><strong><?php echo($token); ?></strong></h4>
                </div>
                <?php
            }
            ?>

        </div>
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
        <script src="vendor/jquery/jquery-1.12.3.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="vendor/nano-scroller/nano-scroller.js"></script>
        <script src="javascripts/template-script.min.js"></script>
        <script src="javascripts/template-init.min.js"></script>
        <script src="vendor/bootstrap_max-lenght/bootstrap-maxlength.js"></script>
        <script src="vendor/select2/js/select2.min.js"></script>
        <script src="vendor/input-masked/inputmask.bundle.min.js"></script>
        <script src="vendor/input-masked/phone-codes/phone.js"></script>
        <script src="vendor/bootstrap_date-picker/js/bootstrap-datepicker.min.js"></script>
        <script src="vendor/bootstrap_time-picker/js/bootstrap-timepicker.js"></script>
        <script src="vendor/bootstrap_color-picker/js/bootstrap-colorpicker.min.js"></script>
        <script src="javascripts/examples/forms/advanced.js"></script>
        <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
        <script src="vendor/data-table/media/js/jquery.dataTables.min.js"></script>
        <script src="vendor/data-table/media/js/dataTables.bootstrap.min.js"></script>
        <script src="vendor/data-table/extensions/Responsive/js/dataTables.responsive.min.js"></script>
        <script src="vendor/data-table/extensions/Responsive/js/responsive.bootstrap.min.js"></script>
        <script src="javascripts/examples/tables/data-tables.js"></script>



    </body>
</html>
